import time
import xbmcplugin
import xbmcgui
import xbmc
import urllib.parse
import time
from cache_utils import cargar_cache, guardar_cache
from actualizar_lista import actualizar_lista


def mostrar_menu_principal(handle, plugin_url, cache_file):
    # Cargar caché o actualizar lista si es la primera ejecución
    cache = cargar_cache(cache_file)

    if not cache:
        xbmc.log("Menú Principal: Caché no encontrada, actualizando lista", level=xbmc.LOGINFO)
        # Forzar una actualización de la lista
        enlaces = actualizar_lista(cache_file, handle)
        if not enlaces:
            xbmcgui.Dialog().notification("Error", "No se pudo obtener canales, verifica la conexión.")
            return
        else:
            # Guardar en caché la lista obtenida
            guardar_cache(cache_file, enlaces)
            xbmc.log("Menú Principal: Lista actualizada y guardada en caché", level=xbmc.LOGINFO)

            # Recargar el menú con la lista actualizada
            cache = enlaces

    # Mostrar el contenido del caché
    xbmcplugin.setPluginCategory(handle, f" Kodipollo")
    # Opción de actualizar lista
    actualizar_item = xbmcgui.ListItem(label="Actualizar lista")
    xbmcplugin.addDirectoryItem(handle, f"{plugin_url}?action=actualizar", actualizar_item, isFolder=False)

    # Añadir los canales del caché al menú
    if cache:
        for  linea in cache:
            titulo = f'{linea["name"]} {(linea["url"])[-4:]}'
            enlace = linea["url"].replace('acestream://', 'plugin://script.module.horus?action=play&id=')

            list_item = xbmcgui.ListItem(label=titulo)
            list_item.setInfo('video', {'title': titulo})
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, enlace, list_item, isFolder=False)
    else:
        xbmc.log("Menú Principal: No hay enlaces ni títulos en caché para mostrar.", level=xbmc.LOGWARNING)

    # Finalizar el directorio
    xbmcplugin.endOfDirectory(handle)



# Manejo de las distintas acciones
# Agregar plugin_url como parámetro de la función
def handle_action(action, handle, cache_file, params, plugin_url):
    if action == 'actualizar':
        enlaces = actualizar_lista(cache_file, handle)
        guardar_cache(cache_file,enlaces)
        mostrar_menu_principal(handle, plugin_url, cache_file)
    else:
        xbmcgui.Dialog().notification("Acción no reconocida", f"La acción '{action}' no está implementada.")

