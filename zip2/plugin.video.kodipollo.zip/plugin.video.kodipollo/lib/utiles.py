import re
import json
import base64

from typing import Optional, Dict, Any, List



def extract_links_data(html_file_path: str) -> Optional[Dict[str, List[Dict[str, Any]]]]:
    """
    Extrae el contenido de la variable 'linksData' dentro de la etiqueta <script> de un archivo HTML.

    Args:
        html_file_path: La ruta al archivo HTML.

    Returns:
        Un diccionario que representa el contenido de 'linksData', o None si no se encuentra.
    """
    try:
        with open(html_file_path, 'r', encoding='utf-8') as f:
            html_content = f.read()

        script_match = re.search(r'<script>(.*?)</script>', html_content, re.DOTALL)
        if script_match:
            script_content = script_match.group(1)
            links_data_match = re.search(r'const linksData\s*=\s*({.*?});', script_content, re.DOTALL)
            if links_data_match:
                links_data_str = links_data_match.group(1)
                # Considera usar ast.literal_eval para una evaluación segura si es necesario.
                # En este caso, asumimos que el JSON dentro de linksData es seguro.
                texto =  eval(links_data_str)
                texto_json = (str(texto.get("links"))).replace("'", '"')
                data = json.loads(texto_json)
                return data
        return None

    except FileNotFoundError:
        print(f"Error: El archivo '{html_file_path}' no fue encontrado.")
        return None
    except Exception as e:
        print(f"Error inesperado: {e}")
        return None


def desofuscado_json_mejorado(datos_ofuscados: str) -> dict:
    """
    Desofuscado una cadena JSON codificada en base64 y cifrada con XOR.

    Args:
        datos_ofuscados: La cadena JSON ofuscada.
        clave_xor: La clave XOR para el descifrado.

    Returns:
        El diccionario JSON desofuscado.
    """
    CLAVE_XOR_FIJA = 81
    datos_cifrados = base64.b64decode(datos_ofuscados)
    datos_json = bytes([b ^ CLAVE_XOR_FIJA for b in datos_cifrados]).decode('utf-8')
    datos_desofuscados = json.loads(datos_json)
    return datos_desofuscados