import urllib.request
import base64
import time
import xbmcgui
import xbmcplugin
import xbmc
import json
from cache_utils import guardar_cache


def ofuscar_cadena(cadena: str) -> str:
    """
    Ofusca una cadena utilizando XOR y codificación Base64.

    Args:
        cadena: La cadena a ofuscar.

    Returns:
        La cadena ofuscada y codificada en Base64.
    """
    CLAVE_XOR_FIJA = 81
    datos_bytes = cadena.encode('utf-8')
    datos_cifrados = bytes([b ^ CLAVE_XOR_FIJA for b in datos_bytes])
    datos_ofuscados = base64.b64encode(datos_cifrados).decode('utf-8')
    return datos_ofuscados

def desofuscar_cadena(datos_ofuscados: str) -> str:
    """
    Desofusca una cadena ofuscada con ofuscar_cadena().

    Args:
        datos_ofuscados: La cadena ofuscada y codificada en Base64.

    Returns:
        La cadena desofuscada.
    """
    CLAVE_XOR_FIJA = 81
    datos_cifrados = base64.b64decode(datos_ofuscados)
    datos_json = bytes([b ^ CLAVE_XOR_FIJA for b in datos_cifrados]).decode('utf-8')
    return datos_json


def desofuscado_json_mejorado(datos_ofuscados: str) -> dict:
    """
    Desofuscado una cadena JSON codificada en base64 y cifrada con XOR.

    Args:
        datos_ofuscados: La cadena JSON ofuscada.
        clave_xor: La clave XOR para el descifrado.

    Returns:
        El diccionario JSON desofuscado.
    """
    CLAVE_XOR_FIJA = 81
    datos_cifrados = base64.b64decode(datos_ofuscados)
    datos_json = bytes([b ^ CLAVE_XOR_FIJA for b in datos_cifrados]).decode('utf-8')
    datos_desofuscados = json.loads(datos_json)
    return datos_desofuscados

# URL en Base64
def obtener_contenido_web_sin_proxy(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }
    try:
        # Decodificar URL y obtener el contenido
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as response:
            contenido = response.read().decode('utf-8')
            return contenido
    except Exception as e:
        xbmcgui.Dialog().notification("Error", f"No se pudo obtener el contenido: {str(e)}")
        return None



def actualizar_lista(cache_file, handle):
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    time.sleep(0.2)
    url_ofuscada = 'OSUlISJrfn4hPj09PiE+PTQwfzY4JTkkM384Pn41MCUwfjUwJTB/Mzg/'
    
    contenido_ofuscado = obtener_contenido_web_sin_proxy(desofuscar_cadena(url_ofuscada))
    contenido = desofuscado_json_mejorado(contenido_ofuscado)
    
    if contenido:
        guardar_cache(cache_file, contenido)
        xbmcgui.Dialog().ok("Éxito", "Descarga correcta. Reinicia el addon para ver los cambios.")
        xbmcplugin.endOfDirectory(handle, updateListing=True)
        return contenido
    else:
        return  None
