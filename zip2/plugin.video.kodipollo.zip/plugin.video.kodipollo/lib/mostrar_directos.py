# lib/mostrar_directos.py
import xbmc
import xbmcgui
import xbmcplugin
import requests

class Event:
    def __init__(self, day, time, name, channel, sport, competition):
        self.day = day
        self.time = time
        self.name = name
        self.channel = channel
        self.sport = sport
        self.competition = competition

def get_tv_programs(url="https://www.marca.com/programacion-tv.html"):
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()

        content = response.text
        events_data = []

        sections = content.split('content-item')
        sections = sections[1:]  # Ignoramos la primera sección

        for section in sections:
            # Extraer el día
            day_start = section.find('title-section-widget')
            if day_start == -1:
                continue
            day_end = section.find('</span>', day_start)
            day = section[day_start:day_end].split('>')[-1].strip()
            day = f"[COLOR yellow][B]{day}[/B][/COLOR]"

            # Extraer eventos
            events = section.split('dailyevent')
            for event in events[1:]:
                # Extraer hora
                time_start = event.find('dailyhour')
                time_end = event.find('</strong>', time_start)
                time_text = event[time_start:time_end].split('>')[-1].strip() if time_start != -1 else "N/A"

                # Extraer nombre del evento
                event_name_start = event.find('dailyteams')
                event_name_end = event.find('</h4>', event_name_start)
                event_name = event[event_name_start:event_name_end].split('>')[-1].strip() if event_name_start != -1 else "N/A"

                # Extraer canal
                channel_start = event.find('dailychannel')
                channel_end = event.find('</span>', channel_start)
                channel = event[channel_start:channel_end].split('>')[-1].strip() if channel_start != -1 else "N/A"

                # Extraer deporte
                sport_start = event.find('dailyday')
                sport_end = event.find('</span>', sport_start)
                sport = event[sport_start:sport_end].split('>')[-1].strip() if sport_start != -1 else "N/A"

                # Extraer competición
                comp_start = event.find('dailycompetition')
                comp_end = event.find('</span>', comp_start)
                competition = event[comp_start:comp_end].split('>')[-1].strip() if comp_start != -1 else "N/A"

                events_data.append(Event(day, time_text, event_name, channel, sport, competition))

        xbmc.log(f"Fetched {len(events_data)} unique TV programs.", level=xbmc.LOGINFO)
        return events_data

    except requests.RequestException as e:
        xbmc.log(f"Failed to retrieve TV programs from {url}: {e}", level=xbmc.LOGERROR)
        return []

def find_closest_channel(channel_name, channels_names):
    best_match = None
    highest_similarity = 0

    for channel in channels_names:
        similarity = sum(a == b for a, b in zip(channel_name.lower(), channel.lower())) / max(len(channel_name), len(channel))
        if similarity > highest_similarity and similarity > 0.7:
            highest_similarity = similarity
            best_match = channel

    return best_match

def mostrar_directos(handle, cache_file=None):
    # Obtener los eventos
    events = get_tv_programs()

    if not events:
        xbmcgui.Dialog().notification("Error", "No se pudieron obtener los eventos")
        return

    # Cargar la cache para obtener los canales disponibles
    from cache_utils import cargar_cache
    cache = cargar_cache(cache_file)
    canales_disponibles = cache.get('titulos', [])
    enlaces_disponibles = cache.get('enlaces', [])

    # Mostrar los eventos
    for event in events:
        title = f"{event.time} - {event.name} ({event.channel})"
        description = f"Deporte: {event.sport}\nCompetición: {event.competition}"

        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo('video', {
            'title': title,
            'plot': description
        })

        # Buscar el canal más cercano
        canal_similar = find_closest_channel(event.channel, canales_disponibles)

        if canal_similar:
            # Obtener el enlace correspondiente al canal similar
            title = f"[COLOR green]▶[/COLOR] {event.time} - {event.name} ({event.channel}) [COLOR yellow]→[/COLOR] {canal_similar}"
            index = canales_disponibles.index(canal_similar)
            enlace_original = enlaces_disponibles[index]

            # Extraer el ID de Acestream del enlace original
            if 'id=' in enlace_original:
                acestream_id = enlace_original.split('id=')[-1]
                # Crear el enlace correcto para Horus
                enlace = f"plugin://script.module.horus/?action=play&id={acestream_id}"

                list_item.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(handle, enlace, list_item, isFolder=False)
            else:
                xbmcplugin.addDirectoryItem(handle, "", list_item, isFolder=False)
        else:
            # Si no hay canal similar, mostrar como no reproducible
            xbmcplugin.addDirectoryItem(handle, "", list_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)
