import xbmc
import xbmcgui
import urllib.parse
import requests

def parse_m3u8_channels(playlist_content):
    """Parse M3U8 content and return a list of channels with their details"""
    channels = []
    current_channel = None

    for line in playlist_content.splitlines():
        if line.startswith('#EXTINF:'):
            channel_info = line.split(',', 1)
            if len(channel_info) > 1:
                channel_name = channel_info[1]
                tvg_name = None
                tvg_logo = None
                group_title = None

                # Parse TVG information if present
                if 'tvg-name="' in line:
                    tvg_name = line.split('tvg-name="')[1].split('"')[0]
                if 'tvg-logo="' in line:
                    tvg_logo = line.split('tvg-logo="')[1].split('"')[0]
                if 'group-title="' in line:
                    group_title = line.split('group-title="')[1].split('"')[0]

                current_channel = {
                    'name': tvg_name or channel_name,
                    'original_name': channel_name,
                    'logo': tvg_logo,
                    'group': group_title,
                    'url': None
                }
        elif line.startswith('#EXTVLCOPT:'):
            continue
        elif line.startswith('#'):
            continue
        elif line.strip() and current_channel is not None:
            current_channel['url'] = line.strip()
            channels.append(current_channel)
            current_channel = None

    return channels

def search_channels(channels):
    """Show search dialog and return filtered channels"""
    dialog = xbmcgui.Dialog()
    search_term = dialog.input('Search Channels', type=xbmcgui.INPUT_ALPHANUM)

    if not search_term:
        return channels

    search_term = search_term.lower()
    return [
        channel for channel in channels
        if search_term in channel['name'].lower() or
           search_term in channel.get('group', '').lower() or
           search_term in channel['original_name'].lower()
    ]

def show_channel_selection(channels):
    """Show channel selection dialog and return selected channel"""
    # Group channels
    groups = {}
    for channel in channels:
        group = channel.get('group', 'No Group')
        if group not in groups:
            groups[group] = []
        groups[group].append(channel)

    priority_groups = [
        'Spain',
        'SPAIN',
        'SPANISH',
        'Other',
        'Argentina'
    ]
    sorted_groups = sorted(groups.items(), key=lambda x: (
        min([999] + [i for i, p in enumerate(priority_groups) if p in x[0].upper()]),
        x[0]  # Después ordena alfabéticamente
    ))
    # Create list items
    items = []
    channels_map = {}  # Map list position to channel data
    current_position = 0

    # Add search option as first item
    search_item = xbmcgui.ListItem('[COLOR yellow]🔍 Search...[/COLOR]')
    items.append(search_item)
    current_position += 1

    # Add channels grouped by category
    for group_name, group_channels in sorted_groups:
        # Add group header
        if group_name != 'No Group':
            group_header = xbmcgui.ListItem(f'[COLOR blue]{group_name}[/COLOR]')
            items.append(group_header)
            current_position += 1

        # Add channels in this group
        for channel in group_channels:
            list_item = xbmcgui.ListItem(channel['name'])
            if channel['logo']:
                list_item.setArt({'thumb': channel['logo'], 'icon': channel['logo']})
            items.append(list_item)
            channels_map[current_position] = channel
            current_position += 1

    # Show dialog
    dialog = xbmcgui.Dialog()
    selected_idx = dialog.select('Select Channel', items, useDetails=True)

    # Handle selection
    if selected_idx == 0:  # Search option selected
        filtered_channels = search_channels(channels)
        return show_channel_selection(filtered_channels)
    elif selected_idx > 0:
        return channels_map.get(selected_idx)

    return None

def select_and_play_channel(playlist_url):
    """Fetch playlist, show channel selection dialog with search, and play selected channel"""
    try:
        # Fetch the playlist content
        response = requests.get(playlist_url, headers={
            "Referer": "https://cookiewebplay.xyz/",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
            "Origin": "https://cookiewebplay.xyz"
        })
        content = response.text

        # Parse channels
        channels = parse_m3u8_channels(content)

        if not channels:
            xbmcgui.Dialog().notification(
                "Error",
                "No channels found in playlist",
                xbmcgui.NOTIFICATION_ERROR,
                3000
            )
            return

        # Show channel selection dialog
        selected_channel = show_channel_selection(channels)

        if selected_channel:
            play_channel(selected_channel['url'])

    except Exception as e:
        xbmcgui.Dialog().notification(
            "Error",
            f"Failed to load channels: {str(e)}",
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        xbmc.log(f"Error in select_and_play_channel: {str(e)}", xbmc.LOGERROR)

def play_channel(stream_url):
    """Play the selected channel stream"""
    try:
        encoded_headers = urllib.parse.urlencode({
            "Referer": "https://cookiewebplay.xyz/",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
            "Origin": "https://cookiewebplay.xyz"
        })
        stream_url_with_headers = f"{stream_url}|{encoded_headers}"

        xbmcgui.Dialog().notification(
            "Playing Stream",
            "Starting playback",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        player = xbmc.Player()
        player.play(stream_url_with_headers)

    except Exception as e:
        xbmcgui.Dialog().notification(
            "Error",
            f"Failed to play stream: {str(e)}",
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        xbmc.log(f"Error in play_channel: {str(e)}", xbmc.LOGERROR)

def play_m3u8_playlist_with_headers(playlist_url):
    """Main entry point that now shows channel selection with search"""
    select_and_play_channel(playlist_url)
