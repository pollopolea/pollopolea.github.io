import urllib.request
import base64
import time
import xbmcgui
import xbmcplugin
import xbmc
import json
from cache_utils import guardar_cache

# URL en Base64
asdf = "aHR0cHM6Ly9pcGZzLmlvL2lwbnMvZWxjYW5vLnRvcA=="

def obtener_contenido_web_sin_proxy():
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }
    try:
        # Decodificar URL y obtener el contenido
        qwert = base64.b64decode(asdf).decode('utf-8')
        req = urllib.request.Request(qwert, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as response:
            contenido = response.read().decode('latin-1')
            # Decodificar el contenido desde Base64
            # contenido = base64.b64decode(contenido_base64).decode('latin-1')
            return contenido
    except Exception as e:
        xbmcgui.Dialog().notification("Error", f"No se pudo obtener el contenido: {str(e)}")
        return None

def extraer_enlaces(contenido):
    enlaces = []
    titulos = []
    try:
        # Buscar el objeto linksData en el contenido
        inicio = contenido.find('const linksData = ') + len('const linksData = ')
        fin = contenido.find('};', inicio) + 1
        if inicio > 0 and fin > 0:
            # Extraer el JSON de linksData
            datos_json = contenido[inicio:fin]
            datos = json.loads(datos_json)

            # Procesar cada enlace
            for link in datos['links']:
                if link['url']:  # Solo procesar si la URL no está vacía
                    # Extraer el ID del acestream
                    acestream_id = link['url'].replace('acestream://', '')
                    # Crear el enlace en el formato para Horus
                    enlace = f"plugin://script.module.horus?action=play&id={acestream_id}"
                    # Crear el título con los últimos 4 caracteres del ID
                    titulo = f"{link['name']} - {acestream_id[-4:]}"
                    enlaces.append(enlace)
                    titulos.append(titulo)

    except Exception as e:
        print(f"Error al procesar el contenido: {str(e)}")

    return enlaces, titulos

def actualizar_lista(cache_file, handle):
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    time.sleep(0.2)
    contenido = obtener_contenido_web_sin_proxy()
    if contenido:
        enlaces, titulos = extraer_enlaces(contenido)
        origen = "Archivo Remoto"
        guardar_cache(cache_file, enlaces, titulos, origen, time.strftime('%d-%m-%Y %H:%M'))
        xbmcgui.Dialog().ok("Éxito", "Descarga correcta. Reinicia el addon para ver los cambios.")
        xbmcplugin.endOfDirectory(handle, updateListing=True)
        return enlaces, titulos, origen, time.strftime('%d-%m-%Y %H:%M')
    else:
        return [], [], "Error en Contenido", None
